//
//  SettingVC.h
//  FeiYong
//
//  Created by 周大钦 on 16/6/8.
//  Copyright © 2016年 ldj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingVC : BaseVC
@property (weak, nonatomic) IBOutlet UITableView *mTableView;
- (IBAction)LoginOutClick:(id)sender;

@end
