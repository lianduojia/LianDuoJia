//
//  AuntDetailCell.m
//  FeiYong
//
//  Created by 周大钦 on 16/8/23.
//  Copyright © 2016年 ldj. All rights reserved.
//

#import "AuntDetailCell.h"

@implementation AuntDetailCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
