//
//  OpinionVC.h
//  FeiYong
//
//  Created by 周大钦 on 16/6/8.
//  Copyright © 2016年 ldj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OpinionVC : BaseVC

@property (weak, nonatomic) IBOutlet UITextView *mOpinion;
@property (weak, nonatomic) IBOutlet UITextField *mName;
@end
