//
//  HealthCareVC.m
//  FeiYong
//
//  Created by 周大钦 on 16/9/18.
//  Copyright © 2016年 ldj. All rights reserved.
//

#import "HealthCareVC.h"

@interface HealthCareVC ()

@end

@implementation HealthCareVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.navTitle = @"养生养老";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
