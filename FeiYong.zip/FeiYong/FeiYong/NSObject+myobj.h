//
//  NSObject+myobj.h
//  com.yizan.vso2o.business
//
//  Created by zzl on 15/4/28.
//  Copyright (c) 2015年 zy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (myobj)
- (id)objectForKeyMy:(id)aKey;
@end
