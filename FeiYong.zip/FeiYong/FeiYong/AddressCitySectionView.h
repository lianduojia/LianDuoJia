//
//  AddressCitySectionView.h
//  FeiYong
//
//  Created by 周大钦 on 16/9/1.
//  Copyright © 2016年 ldj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddressCitySectionView : UIView
@property (weak, nonatomic) IBOutlet UILabel *mLabel;

+ (AddressCitySectionView *)shareView;

@end
