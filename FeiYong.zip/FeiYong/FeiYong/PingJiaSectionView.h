//
//  PingJiaSectionView.h
//  FeiYong
//
//  Created by 周大钦 on 16/6/8.
//  Copyright © 2016年 ldj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PingJiaSectionView : UIView

+ (PingJiaSectionView *)shareView;
@property (weak, nonatomic) IBOutlet UIButton *mbt1;
@property (weak, nonatomic) IBOutlet UIButton *mbt2;
@property (weak, nonatomic) IBOutlet UIButton *mbt3;
@property (weak, nonatomic) IBOutlet UIButton *mbt4;

@end
