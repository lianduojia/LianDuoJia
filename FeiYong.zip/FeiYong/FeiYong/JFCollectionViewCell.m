//
//  JFCollectionViewCell.m
//  FeiYong
//
//  Created by 周大钦 on 16/6/7.
//  Copyright © 2016年 ldj. All rights reserved.
//

#import "JFCollectionViewCell.h"

@implementation JFCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
