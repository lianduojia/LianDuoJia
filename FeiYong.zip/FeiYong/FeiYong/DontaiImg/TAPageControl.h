//
//  TAPageControl.h
//  scrollV
//
//  Created by touchwaves studio on 15/3/27.
//  Copyright (c) 2015年 ST. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TAPageControl : UIPageControl

@end
