//
//  CityListVC.h
//  FeiYong
//
//  Created by 周大钦 on 16/7/12.
//  Copyright © 2016年 ldj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CityListVC : BaseVC
@property (weak, nonatomic) IBOutlet UICollectionView *mCollectionView;

@end
